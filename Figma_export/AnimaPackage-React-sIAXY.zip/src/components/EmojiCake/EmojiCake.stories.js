import { EmojiCake } from ".";

export default {
  title: "Components/EmojiCake",
  component: EmojiCake,
};

export const Default = {
  args: {
    className: {},
  },
};

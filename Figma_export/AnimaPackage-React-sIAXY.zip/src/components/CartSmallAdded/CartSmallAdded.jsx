/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { BadgeQuantity } from "../BadgeQuantity";
import "./style.css";

export const CartSmallAdded = ({ className, badgeQuantityText = "99" }) => {
  return (
    <div className={`cart-small-added ${className}`}>
      <BadgeQuantity
        className="badge-quantity-indicator-small"
        overlapGroupClassName="badge-quantity-instance"
        text={badgeQuantityText}
      />
    </div>
  );
};

CartSmallAdded.propTypes = {
  badgeQuantityText: PropTypes.string,
};

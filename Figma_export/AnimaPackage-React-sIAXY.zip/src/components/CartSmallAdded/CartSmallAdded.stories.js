import { CartSmallAdded } from ".";

export default {
  title: "Components/CartSmallAdded",
  component: CartSmallAdded,
};

export const Default = {
  args: {
    className: {},
    badgeQuantityText: "99",
  },
};

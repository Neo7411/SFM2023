import { EmojiBroccoli } from ".";

export default {
  title: "Components/EmojiBroccoli",
  component: EmojiBroccoli,
};

export const Default = {
  args: {
    className: {},
  },
};

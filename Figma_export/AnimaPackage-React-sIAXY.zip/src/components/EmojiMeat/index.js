export { EmojiMeat } from "./EmojiMeat";

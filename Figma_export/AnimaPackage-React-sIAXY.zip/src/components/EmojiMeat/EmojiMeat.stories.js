import { EmojiMeat } from ".";

export default {
  title: "Components/EmojiMeat",
  component: EmojiMeat,
};

export const Default = {
  args: {
    className: {},
  },
};

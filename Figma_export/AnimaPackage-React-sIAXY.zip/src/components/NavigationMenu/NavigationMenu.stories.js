import { NavigationMenu } from ".";

export default {
  title: "Components/NavigationMenu",
  component: NavigationMenu,
};

export const Default = {
  args: {
    className: {},
    overlapClassName: {},
    navigationAvatarOtherMainAvatarOtherMain: "/img/avatar-other-main-avatar-1.svg",
    itemsClassName: {},
  },
};

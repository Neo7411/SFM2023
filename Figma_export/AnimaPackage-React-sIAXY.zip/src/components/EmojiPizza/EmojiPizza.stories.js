import { EmojiPizza } from ".";

export default {
  title: "Components/EmojiPizza",
  component: EmojiPizza,
};

export const Default = {
  args: {
    className: {},
  },
};

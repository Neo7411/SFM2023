import { CardElementsTitle } from ".";

export default {
  title: "Components/CardElementsTitle",
  component: CardElementsTitle,
};

export const Default = {
  args: {
    className: {},
    text: "Card title",
    text1: "00-99 min",
    text2: "$99 min sum",
  },
};

/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { IconOutlinedActionMainClock6 } from "../../icons/IconOutlinedActionMainClock6";
import { IconOutlinedOtherShopShoppingBag12 } from "../../icons/IconOutlinedOtherShopShoppingBag12";
import "./style.css";

export const CardElementsTitle = ({ className, text = "Card title", text1 = "00-99 min", text2 = "$99 min sum" }) => {
  return (
    <div className={`card-elements-title ${className}`}>
      <div className="card-title">{text}</div>
      <IconOutlinedActionMainClock6 className="icon-outlined-action" />
      <div className="time-and-amount">
        <div className="div">{text1}</div>
        <div className="ellipse" />
        <div className="div">{text2}</div>
      </div>
      <IconOutlinedOtherShopShoppingBag12 className="icon-outlined-other" color="#C7C8D2" />
    </div>
  );
};

CardElementsTitle.propTypes = {
  text: PropTypes.string,
  text1: PropTypes.string,
  text2: PropTypes.string,
};

import { Navigation } from ".";

export default {
  title: "Components/Navigation",
  component: Navigation,
};

export const Default = {
  args: {
    className: {},
    avatarOtherMainAvatarOtherMain: "/img/avatar-other-main-avatar-2.svg",
  },
};

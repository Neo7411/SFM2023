/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { AvatarOtherMain } from "../AvatarOtherMain";
import "./style.css";

export const Navigation = ({ className, avatarOtherMainAvatarOtherMain = "/img/avatar-other-main-avatar-2.svg" }) => {
  return (
    <div className={`navigation ${className}`}>
      <div className="avatar-other-main-wrapper">
        <AvatarOtherMain avatarOtherMain={avatarOtherMainAvatarOtherMain} className="avatar-other-main-avatar" />
      </div>
    </div>
  );
};

Navigation.propTypes = {
  avatarOtherMainAvatarOtherMain: PropTypes.string,
};

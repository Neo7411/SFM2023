import { BadgeContent } from ".";

export default {
  title: "Components/BadgeContent",
  component: BadgeContent,
};

export const Default = {
  args: {
    className: {},
  },
};

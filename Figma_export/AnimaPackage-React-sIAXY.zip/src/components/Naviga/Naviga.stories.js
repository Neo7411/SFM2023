import { Naviga } from ".";

export default {
  title: "Components/Naviga",
  component: Naviga,
};

export const Default = {
  args: {
    className: {},
  },
};

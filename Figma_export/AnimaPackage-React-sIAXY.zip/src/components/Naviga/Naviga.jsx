/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";
import { StandardCollection20 } from "../../icons/StandardCollection20";
import { NavigationMenu } from "../NavigationMenu";
import "./style.css";

export const Naviga = ({ className, navigationMenu = <StandardCollection20 className="standard-collection" /> }) => {
  return (
    <div className={`naviga ${className}`}>
      <NavigationMenu
        className="navigation-menu-horizontal-example-desktop-main-app"
        itemsClassName="navigation-menu-horizontal-example-desktop-main-app-instance"
        navigationAvatarOtherMainAvatarOtherMain="/img/avatar-other-main-avatar.svg"
        overlapClassName="navigation-menu-instance"
        override={navigationMenu}
      />
    </div>
  );
};

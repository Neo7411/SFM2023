import { BadgeIconLeft } from ".";

export default {
  title: "Components/BadgeIconLeft",
  component: BadgeIconLeft,
};

export const Default = {
  args: {
    className: {},
    text: "Label",
  },
};

/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { EmojiPizza } from "../EmojiPizza";
import "./style.css";

export const BadgeIconLeft = ({ className, override = <EmojiPizza className="emoji-pizza-2" />, text = "Label" }) => {
  return (
    <div className={`badge-icon-left ${className}`}>
      {override}
      <div className="label-2">{text}</div>
    </div>
  );
};

BadgeIconLeft.propTypes = {
  text: PropTypes.string,
};

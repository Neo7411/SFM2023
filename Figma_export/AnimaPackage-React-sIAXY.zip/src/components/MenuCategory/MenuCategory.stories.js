import { MenuCategory } from ".";

export default {
  title: "Components/MenuCategory",
  component: MenuCategory,
};

export const Default = {
  args: {
    className: {},
    text: "Label",
  },
};

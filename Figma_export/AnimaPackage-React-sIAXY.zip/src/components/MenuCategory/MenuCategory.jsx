/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { EmojiPizza } from "../EmojiPizza";
import "./style.css";

export const MenuCategory = ({
  className,
  override = <EmojiPizza className="emoji-pizza-instance" />,
  text = "Label",
}) => {
  return (
    <div className={`menu-category ${className}`}>
      {override}
      <div className="label">{text}</div>
    </div>
  );
};

MenuCategory.propTypes = {
  text: PropTypes.string,
};

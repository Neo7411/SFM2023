/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { BadgeContent } from "../BadgeContent";
import { BadgeIconLeft } from "../BadgeIconLeft";
import { CardElementsTitle } from "../CardElementsTitle";
import { EmojiBroccoli } from "../EmojiBroccoli";
import { EmojiBurger } from "../EmojiBurger";
import { EmojiPizza } from "../EmojiPizza";
import { EmojiSushi } from "../EmojiSushi";
import "./style.css";

export const CardExample = ({
  className,
  badgeIconLeft = <EmojiSushi className="emoji-sushi-instance" />,
  visible = true,
  visible1 = true,
  visible2 = true,
}) => {
  return (
    <div className={`card-example ${className}`}>
      <CardElementsTitle
        className="card-elements-title-restaurant"
        text="Royal Sushi House"
        text1="30-40 min"
        text2="$32 min sum"
      />
      <div className="overlap-group">
        <BadgeContent className="badge-content-indicator-featured" />
      </div>
      <div className="badges">
        <BadgeIconLeft className="badge-icon-left-default" override={badgeIconLeft} text="Sushi" />
        {visible && (
          <BadgeIconLeft
            className="badge-icon-left-default"
            override={<EmojiBurger className="emoji-burger-instance" />}
            text="Burger"
          />
        )}

        {visible1 && (
          <BadgeIconLeft
            className="badge-icon-left-default"
            override={<EmojiPizza className="emoji-pizza-3" />}
            text="Pizza"
          />
        )}

        {visible2 && (
          <BadgeIconLeft
            className="badge-icon-left-default"
            override={<EmojiBroccoli className="emoji-broccoli-instance" />}
            text="Vegan"
          />
        )}
      </div>
    </div>
  );
};

CardExample.propTypes = {
  visible: PropTypes.bool,
  visible1: PropTypes.bool,
  visible2: PropTypes.bool,
};

import { CardExample } from ".";

export default {
  title: "Components/CardExample",
  component: CardExample,
};

export const Default = {
  args: {
    className: {},
    visible: true,
    visible1: true,
    visible2: true,
  },
};

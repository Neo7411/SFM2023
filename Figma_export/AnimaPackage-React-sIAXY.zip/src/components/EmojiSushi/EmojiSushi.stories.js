import { EmojiSushi } from ".";

export default {
  title: "Components/EmojiSushi",
  component: EmojiSushi,
};

export const Default = {
  args: {
    className: {},
  },
};

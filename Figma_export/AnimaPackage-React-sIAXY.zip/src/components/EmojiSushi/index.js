export { EmojiSushi } from "./EmojiSushi";

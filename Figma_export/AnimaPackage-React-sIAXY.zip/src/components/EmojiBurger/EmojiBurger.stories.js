import { EmojiBurger } from ".";

export default {
  title: "Components/EmojiBurger",
  component: EmojiBurger,
};

export const Default = {
  args: {
    className: {},
  },
};

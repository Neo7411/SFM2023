export { EmojiBurger } from "./EmojiBurger";

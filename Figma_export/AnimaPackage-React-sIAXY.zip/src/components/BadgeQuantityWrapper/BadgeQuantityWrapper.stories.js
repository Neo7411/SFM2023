import { BadgeQuantityWrapper } from ".";

export default {
  title: "Components/BadgeQuantityWrapper",
  component: BadgeQuantityWrapper,
};

export const Default = {
  args: {
    className: {},
    text: "99",
  },
};

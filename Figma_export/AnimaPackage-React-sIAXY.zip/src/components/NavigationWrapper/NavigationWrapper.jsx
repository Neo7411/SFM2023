/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";
import { IconOutlinedOtherShopShoppingBag12 } from "../../icons/IconOutlinedOtherShopShoppingBag12";
import { BadgeQuantityWrapper } from "../BadgeQuantityWrapper";
import "./style.css";

export const NavigationWrapper = ({ className }) => {
  return (
    <div className={`navigation-wrapper ${className}`}>
      <div className="overlap-group-2">
        <IconOutlinedOtherShopShoppingBag12 className="icon-outlined-other-shop-shopping-bag-12" color="#4E60FF" />
        <BadgeQuantityWrapper className="badge-quantity-indicator-default" text="4" />
      </div>
    </div>
  );
};

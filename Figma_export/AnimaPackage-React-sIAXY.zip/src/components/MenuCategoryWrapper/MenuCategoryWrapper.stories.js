import { MenuCategoryWrapper } from ".";

export default {
  title: "Components/MenuCategoryWrapper",
  component: MenuCategoryWrapper,
};

export const Default = {
  args: {
    className: {},
    text: "Label",
  },
};

export { IconOutlinedOtherShopShoppingBag12 } from "./IconOutlinedOtherShopShoppingBag12";

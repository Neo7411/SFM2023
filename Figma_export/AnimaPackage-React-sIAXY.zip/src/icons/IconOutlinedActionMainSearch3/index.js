export { IconOutlinedActionMainSearch3 } from "./IconOutlinedActionMainSearch3";

/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const NavigationHorizontalElementsSheetWhite1 = ({ className }) => {
  return (
    <svg
      className={`navigation-horizontal-elements-sheet-white-1 ${className}`}
      fill="none"
      height="81"
      viewBox="0 0 1440 81"
      width="1440"
      xmlns="http://www.w3.org/2000/svg"
    >
      <rect className="rect" fill="white" height="80" width="1440" />
      <path className="path" d="M0 80H1440" stroke="#EDEEF2" />
    </svg>
  );
};

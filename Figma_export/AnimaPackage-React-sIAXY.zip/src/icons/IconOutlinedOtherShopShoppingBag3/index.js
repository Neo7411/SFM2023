export { IconOutlinedOtherShopShoppingBag3 } from "./IconOutlinedOtherShopShoppingBag3";

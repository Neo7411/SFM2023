import React from "react";
import { BadgeContent } from "../../components/BadgeContent";
import { BadgeIconLeft } from "../../components/BadgeIconLeft";
import { CardElementsTitle } from "../../components/CardElementsTitle";
import { CardExample } from "../../components/CardExample";
import { CartSmallAdded } from "../../components/CartSmallAdded";
import { EmojiBroccoli } from "../../components/EmojiBroccoli";
import { EmojiBurger } from "../../components/EmojiBurger";
import { EmojiCake } from "../../components/EmojiCake";
import { EmojiMeat } from "../../components/EmojiMeat";
import { EmojiPizza } from "../../components/EmojiPizza";
import { EmojiSushi } from "../../components/EmojiSushi";
import { MenuCategory } from "../../components/MenuCategory";
import { MenuCategoryWrapper } from "../../components/MenuCategoryWrapper";
import { Naviga } from "../../components/Naviga";
import { IconOutlinedActionMainClock6 } from "../../icons/IconOutlinedActionMainClock6";
import { StandardCollection20 } from "../../icons/StandardCollection20";
import "./style.css";

export const ElementHome = () => {
  return (
    <div className="element-home">
      <div className="div-2">
        <div className="text-wrapper-4">Nearby restaurants</div>
        <div className="deals">
          <div className="deal">
            <img className="img-mask" alt="Img mask" src="/img/img-mask-7.png" />
            <div className="text-wrapper-5">Big Burgers</div>
            <div className="text-wrapper-6">Fooddies</div>
            <div className="text-wrapper-7">50% OFF</div>
          </div>
          <div className="deal-2">
            <img className="fagyi" alt="Fagyi" src="/img/fagyi.png" />
            <div className="text-wrapper-6">Deserty</div>
            <div className="text-wrapper-8">20% OFF</div>
            <img className="img-mask" alt="Img mask" src="/img/img-mask-6.png" />
          </div>
        </div>
        <div className="categories">
          <div className="menu-category-hover">
            <EmojiPizza className="design-component-instance-node-2" />
            <div className="label-3">Pizza</div>
          </div>
          <MenuCategory
            className="menu-category-selected"
            override={<EmojiBurger className="design-component-instance-node-3" />}
            text="Burger"
          />
          <MenuCategoryWrapper
            className="menu-category-default"
            override={<EmojiMeat className="design-component-instance-node-2" />}
            text="BBQ"
          />
          <MenuCategory
            className="menu-category-instance"
            override={<EmojiSushi className="design-component-instance-node-3" />}
            text="Sushi"
          />
          <MenuCategoryWrapper
            className="menu-category-default-instance"
            override={<EmojiBroccoli className="design-component-instance-node-2" />}
            text="Vegan"
          />
          <MenuCategoryWrapper
            className="menu-category-2"
            override={<EmojiCake className="design-component-instance-node-2" />}
            text="Desserts"
          />
        </div>
        <div className="restaurants">
          <CardExample
            badgeIconLeft={<EmojiSushi className="emoji-sushi-2" />}
            className="design-component-instance-node-4"
            visible={false}
            visible1={false}
            visible2={false}
          />
          <div className="card-example-2">
            <CardElementsTitle
              className="card-elements-title-instance"
              text="Ninja sushi"
              text1="20-40 min"
              text2="$40 min sum"
            />
            <img className="img" alt="Img mask" src="/img/img-mask-4.png" />
            <div className="badges-2">
              <BadgeIconLeft
                className="badge-icon-left-instance"
                override={<EmojiSushi className="emoji-sushi-2" />}
                text="Sushi"
              />
            </div>
          </div>
          <div className="card-example-3">
            <div className="card-elements-title-2">
              <div className="card-title-2">Burgers &amp; Pizza</div>
              <IconOutlinedActionMainClock6 className="icon-outlined-action-main-clock-6" />
              <div className="time-and-amount-2">
                <div className="text-wrapper-9">40-60 min</div>
                <div className="ellipse-2" />
                <div className="text-wrapper-9">$24 min sum</div>
              </div>
              <CartSmallAdded badgeQuantityText="2" className="cart-small-added-instance" />
            </div>
            <div className="badge-content-wrapper">
              <BadgeContent className="badge-content-instance" />
            </div>
            <div className="badges-2">
              <BadgeIconLeft
                className="badge-icon-left-instance"
                override={<EmojiBurger className="emoji-burger-2" />}
                text="Burger"
              />
              <BadgeIconLeft
                className="badge-icon-left-instance"
                override={<EmojiPizza className="emoji-pizza-4" />}
                text="Pizza"
              />
            </div>
          </div>
          <div className="card-example-4">
            <CardElementsTitle
              className="card-elements-title-instance"
              text="Sushi master"
              text1="60-70 min"
              text2="$49 min sum"
            />
            <img className="img-mask-2" alt="Img mask" src="/img/img-mask-2.png" />
            <div className="badges-2">
              <div className="badge-icon-left-2">
                <div className="emoji-sushi-wrapper">
                  <img
                    className="emoji-sushi-3"
                    alt="Emoji sushi"
                    src="/img/icon-outlined-other-shop-shopping-bag-5.png"
                  />
                </div>
                <div className="label-4">Sushi</div>
              </div>
            </div>
          </div>
          <div className="card-example-5">
            <CardElementsTitle
              className="card-elements-title-instance"
              text="Japanese sushi"
              text1="30-50 min"
              text2="$104 min sum"
            />
            <img className="img-mask-2" alt="Img mask" src="/img/img-mask-1.png" />
            <div className="badges-2">
              <div className="badge-icon-left-2">
                <div className="emoji-sushi-wrapper">
                  <img
                    className="emoji-sushi-4"
                    alt="Emoji sushi"
                    src="/img/icon-outlined-other-shop-shopping-bag-5.png"
                  />
                </div>
                <div className="label-4">Sushi</div>
              </div>
            </div>
          </div>
          <div className="card-example-6">
            <CardElementsTitle
              className="card-elements-title-instance"
              text="Kobe"
              text1="20-30 min"
              text2="$57 min sum"
            />
            <img className="img-mask-2" alt="Img mask" src="/img/img-mask.png" />
            <div className="badges-2">
              <BadgeIconLeft
                className="badge-icon-left-instance"
                override={<EmojiSushi className="emoji-sushi-5" />}
                text="Sushi"
              />
            </div>
          </div>
        </div>
        <Naviga
          className="design-component-instance-node-4"
          navigationMenu={<StandardCollection20 className="standard-collection-20" />}
        />
      </div>
    </div>
  );
};

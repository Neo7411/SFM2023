import React from "react";
import ReactDOMClient from "react-dom/client";
import { ElementHome } from "./screens/ElementHome";

const app = document.getElementById("app");
const root = ReactDOMClient.createRoot(app);
root.render(<ElementHome />);

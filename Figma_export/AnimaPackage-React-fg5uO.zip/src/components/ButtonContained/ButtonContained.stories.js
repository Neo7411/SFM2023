import { ButtonContained } from ".";

export default {
  title: "Components/ButtonContained",
  component: ButtonContained,
};

export const Default = {
  args: {
    className: {},
    divClassName: {},
    text: "Button",
  },
};

import { ControlsCheckbox } from ".";

export default {
  title: "Components/ControlsCheckbox",
  component: ControlsCheckbox,
};

export const Default = {
  args: {
    className: {},
  },
};

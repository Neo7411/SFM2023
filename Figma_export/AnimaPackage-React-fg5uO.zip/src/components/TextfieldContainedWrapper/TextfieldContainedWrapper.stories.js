import { TextfieldContainedWrapper } from ".";

export default {
  title: "Components/TextfieldContainedWrapper",
  component: TextfieldContainedWrapper,
};

export const Default = {
  args: {
    className: {},
    overlapGroupClassName: {},
    divClassName: {},
    text: "Placeholder",
    iconOutlinedActionEyeEyeOnStyleOverrideClassName: {},
    divClassNameOverride: {},
    text1: "Label",
  },
};

/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { IconOutlinedActionEyeEyeOn } from "../../icons/IconOutlinedActionEyeEyeOn";
import "./style.css";

export const TextfieldContainedWrapper = ({
  className,
  overlapGroupClassName,
  divClassName,
  text = "Placeholder",
  iconOutlinedActionEyeEyeOnStyleOverrideClassName,
  divClassNameOverride,
  text1 = "Label",
}) => {
  return (
    <div className={`textfield-contained-wrapper ${className}`}>
      <div className={`div ${overlapGroupClassName}`}>
        <div className={`text-wrapper ${divClassName}`}>{text}</div>
        <IconOutlinedActionEyeEyeOn className={iconOutlinedActionEyeEyeOnStyleOverrideClassName} />
      </div>
      <div className={`label-2 ${divClassNameOverride}`}>{text1}</div>
    </div>
  );
};

TextfieldContainedWrapper.propTypes = {
  text: PropTypes.string,
  text1: PropTypes.string,
};

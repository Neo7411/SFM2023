import { TextfieldContained } from ".";

export default {
  title: "Components/TextfieldContained",
  component: TextfieldContained,
};

export const Default = {
  args: {
    className: {},
    overlapGroupClassName: {},
    divClassName: {},
    text: "Placeholder",
    divClassNameOverride: {},
    text1: "Label",
  },
};

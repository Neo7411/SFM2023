import { ControlsCheckboxWrapper } from ".";

export default {
  title: "Components/ControlsCheckboxWrapper",
  component: ControlsCheckboxWrapper,
};

export const Default = {
  args: {
    className: {},
    divClassName: {},
    text: "Checkbox",
  },
};

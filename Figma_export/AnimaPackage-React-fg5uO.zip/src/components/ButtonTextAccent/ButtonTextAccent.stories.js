import { ButtonTextAccent } from ".";

export default {
  title: "Components/ButtonTextAccent",
  component: ButtonTextAccent,
};

export const Default = {
  args: {
    className: {},
    divClassName: {},
    text: "Button",
  },
};

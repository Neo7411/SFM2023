export { IconOutlinedActionThumbThumbUp } from "./IconOutlinedActionThumbThumbUp";

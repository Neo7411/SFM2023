export { IconOutlinedActionMainStar10 } from "./IconOutlinedActionMainStar10";

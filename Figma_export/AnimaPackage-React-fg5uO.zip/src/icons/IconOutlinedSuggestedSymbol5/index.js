export { IconOutlinedSuggestedSymbol5 } from "./IconOutlinedSuggestedSymbol5";

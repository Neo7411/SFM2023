export { IconOutlinedSuggestedSymbol4 } from "./IconOutlinedSuggestedSymbol4";

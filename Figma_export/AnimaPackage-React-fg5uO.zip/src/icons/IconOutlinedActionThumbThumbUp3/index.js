export { IconOutlinedActionThumbThumbUp3 } from "./IconOutlinedActionThumbThumbUp3";

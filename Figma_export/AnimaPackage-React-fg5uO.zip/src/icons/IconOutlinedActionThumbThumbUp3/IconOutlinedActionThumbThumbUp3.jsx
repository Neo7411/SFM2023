/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const IconOutlinedActionThumbThumbUp3 = ({ className }) => {
  return (
    <svg
      className={`icon-outlined-action-thumb-thumb-up-3 ${className}`}
      fill="none"
      height="16"
      viewBox="0 0 16 16"
      width="16"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M4.66667 14.6667H2.66667C2.31304 14.6667 1.97391 14.5262 1.72386 14.2761C1.47381 14.0261 1.33333 13.687 1.33333 13.3333V8.66667C1.33333 8.31304 1.47381 7.97391 1.72386 7.72386C1.97391 7.47381 2.31304 7.33333 2.66667 7.33333H4.66667M9.33333 6V3.33333C9.33333 2.8029 9.12262 2.29419 8.74755 1.91912C8.37247 1.54405 7.86377 1.33333 7.33333 1.33333L4.66667 7.33333V14.6667H12.1867C12.5082 14.6703 12.8203 14.5576 13.0653 14.3493C13.3103 14.1411 13.4718 13.8513 13.52 13.5333L14.44 7.53333C14.469 7.34224 14.4561 7.14712 14.4022 6.9615C14.3483 6.77588 14.2547 6.6042 14.1279 6.45834C14.0011 6.31249 13.8441 6.19595 13.6677 6.11681C13.4914 6.03767 13.2999 5.99781 13.1067 6H9.33333Z"
        stroke="#83859C"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};

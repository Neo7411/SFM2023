export { IconOutlinedActionThumbThumbDown } from "./IconOutlinedActionThumbThumbDown";

export { IconOutlinedSuggestedSymbol1 } from "./IconOutlinedSuggestedSymbol1";

/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";

export const IconOutlinedActionMainStar = ({ color = "#4E60FF", opacity = "unset", className }) => {
  return (
    <svg
      className={`icon-outlined-action-main-star ${className}`}
      fill="none"
      height="14"
      viewBox="0 0 14 14"
      width="14"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M6.46198 2.25664C6.68208 1.81074 7.31792 1.81074 7.53803 2.25664L8.66303 4.53579C8.75036 4.71269 8.91907 4.83537 9.11428 4.8639L11.6311 5.23177C12.123 5.30367 12.3191 5.90838 11.9629 6.25528L10.1427 8.02814C10.0012 8.16598 9.93662 8.36466 9.97002 8.55938L10.3995 11.0632C10.4835 11.5534 9.969 11.9272 9.52882 11.6957L7.27927 10.5127C7.10444 10.4208 6.89556 10.4208 6.72073 10.5127L4.47118 11.6957C4.031 11.9272 3.51647 11.5534 3.60054 11.0632L4.02999 8.55938C4.06338 8.36466 3.99879 8.16598 3.85726 8.02814L2.03708 6.25528C1.68092 5.90838 1.87699 5.30368 2.36894 5.23177L4.88572 4.8639C5.08093 4.83537 5.24965 4.71269 5.33697 4.53579L6.46198 2.25664Z"
        fill={color}
        opacity={opacity}
      />
    </svg>
  );
};

IconOutlinedActionMainStar.propTypes = {
  color: PropTypes.string,
  opacity: PropTypes.string,
};

export { IconOutlinedActionMainStar } from "./IconOutlinedActionMainStar";

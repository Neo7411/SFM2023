export { IconOutlinedSuggestedSymbol8 } from "./IconOutlinedSuggestedSymbol8";

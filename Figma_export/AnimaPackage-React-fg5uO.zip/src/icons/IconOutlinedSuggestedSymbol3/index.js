export { IconOutlinedSuggestedSymbol3 } from "./IconOutlinedSuggestedSymbol3";

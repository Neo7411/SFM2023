export { IconOutlinedActionThumbThumbDown3 } from "./IconOutlinedActionThumbThumbDown3";

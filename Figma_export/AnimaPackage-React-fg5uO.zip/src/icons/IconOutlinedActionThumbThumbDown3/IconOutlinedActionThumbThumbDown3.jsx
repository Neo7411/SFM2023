/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const IconOutlinedActionThumbThumbDown3 = ({ className }) => {
  return (
    <svg
      className={`icon-outlined-action-thumb-thumb-down-3 ${className}`}
      fill="none"
      height="16"
      viewBox="0 0 16 16"
      width="16"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M11.3333 1.33333H13.1133C13.4906 1.32666 13.8573 1.45876 14.1436 1.70455C14.43 1.95034 14.6161 2.29271 14.6667 2.66667V7.33333C14.6161 7.70729 14.43 8.04967 14.1436 8.29545C13.8573 8.54124 13.4906 8.67334 13.1133 8.66667H11.3333M6.66667 10V12.6667C6.66667 13.1971 6.87738 13.7058 7.25245 14.0809C7.62753 14.456 8.13624 14.6667 8.66667 14.6667L11.3333 8.66667V1.33333H3.81333C3.49178 1.3297 3.17975 1.4424 2.93473 1.65066C2.68971 1.85893 2.52822 2.14873 2.48 2.46667L1.56 8.46667C1.531 8.65776 1.54389 8.85288 1.59777 9.0385C1.65166 9.22412 1.74527 9.3958 1.8721 9.54166C1.99892 9.68751 2.15595 9.80405 2.33229 9.88319C2.50863 9.96233 2.70006 10.0022 2.89333 10H6.66667Z"
        stroke="#83859C"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};

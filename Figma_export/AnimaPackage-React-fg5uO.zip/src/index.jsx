import React from "react";
import ReactDOMClient from "react-dom/client";
import { ElementLogin } from "./screens/ElementLogin";

const app = document.getElementById("app");
const root = ReactDOMClient.createRoot(app);
root.render(<ElementLogin />);

import React from "react";
import { ButtonContained } from "../../components/ButtonContained";
import { ButtonTextAccent } from "../../components/ButtonTextAccent";
import { ControlsCheckboxWrapper } from "../../components/ControlsCheckboxWrapper";
import { TextfieldContained } from "../../components/TextfieldContained";
import { TextfieldContainedWrapper } from "../../components/TextfieldContainedWrapper";
import { StandardCollection20 } from "../../icons/StandardCollection20";
import "./style.css";

export const ElementLogin = () => {
  return (
    <div className="element-login">
      <div className="div-2">
        <StandardCollection20 className="standard-collection" />
        <div className="text-wrapper-2">Login</div>
        <p className="p">Sign in with your data that you entered during your registration.</p>
        <TextfieldContained
          className="textfield-contained-input-field-default"
          divClassName="textfield-contained-input-field-default-instance"
          divClassNameOverride="textfield-contained-instance"
          overlapGroupClassName="textfield-contained-instance"
          text="name@example.com"
          text1="Email"
        />
        <TextfieldContainedWrapper
          className="textfield-contained-input-right-icon-default"
          divClassName="textfield-contained-input-right-icon-default-instance"
          divClassNameOverride="textfield-contained-instance"
          iconOutlinedActionEyeEyeOnStyleOverrideClassName="design-component-instance-node"
          overlapGroupClassName="textfield-contained-instance"
          text="min. 8 characters"
          text1="Password"
        />
        <ControlsCheckboxWrapper
          className="controls-checkbox-with-text-unselected-default"
          divClassName="controls-checkbox-instance"
          text="Keep me logged in"
        />
        <ButtonContained
          className="button-contained-accent-default"
          divClassName="design-component-instance-node-2"
          text="Login"
        />
        <ButtonTextAccent
          className="button-text-accent-default"
          divClassName="design-component-instance-node-2"
          text="Forgot password"
        />
        <p className="don-t-have-an">
          <span className="span">Don’t have an account? </span>
          <span className="text-wrapper-3">Sign up</span>
        </p>
        <div className="rectangle" />
      </div>
    </div>
  );
};

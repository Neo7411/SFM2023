import React from "react";
import { ButtonContained } from "../../components/ButtonContained";
import { IconOutlinedAction } from "../../components/IconOutlinedAction";
import { Naviga } from "../../components/Naviga";
import { StandardCollection20 } from "../../icons/StandardCollection20";
import "./style.css";

export const ElementDelivery = () => {
  return (
    <div className="element-delivery">
      <div className="div-2">
        <Naviga
          className="naviga-instance"
          navigationMenu={<StandardCollection20 className="standard-collection-20" />}
          navigationMenuNavigationAvatarOtherMainAvatarOtherMain="/img/avatar-other-main-avatar.svg"
          navigationMenuOverlapClassName="design-component-instance-node"
        />
        <div className="text-wrapper-2">Select Courier</div>
        <div className="settings">
          <div className="menu-item-with-icon">
            <div className="label">MC István</div>
            <div className="secondary">MÁV</div>
            <div className="icon">
              <img className="box" alt="Box" src="/img/box-3.svg" />
            </div>
          </div>
          <div className="menu-item-with-icon-2">
            <div className="label-2">Józssef</div>
            <div className="secondary-2">Motorbike</div>
            <div className="icon-2">
              <img className="box" alt="Box" src="/img/box-2.svg" />
            </div>
          </div>
          <div className="menu-item-with-icon-3">
            <div className="label-2">T-bor</div>
            <div className="secondary-2">E-bike</div>
            <div className="icon-2">
              <img className="box" alt="Box" src="/img/box-1.svg" />
            </div>
          </div>
          <div className="menu-item-with-icon-4">
            <div className="label-2">Antonio</div>
            <div className="secondary-2">Tram no. 2</div>
            <div className="icon-2">
              <div className="overlap-group-2">
                <img className="box" alt="Box" src="/img/box.svg" />
                <IconOutlinedAction />
              </div>
            </div>
          </div>
          <img className="map" alt="Map" src="/img/map.png" />
        </div>
        <ButtonContained
          className="button-contained-accent-default"
          divClassName="button-contained-instance"
          text="Confim"
        />
      </div>
    </div>
  );
};

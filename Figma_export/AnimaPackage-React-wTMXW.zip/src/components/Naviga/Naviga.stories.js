import { Naviga } from ".";

export default {
  title: "Components/Naviga",
  component: Naviga,
};

export const Default = {
  args: {
    className: {},
    navigationMenuNavigationAvatarOtherMainAvatarOtherMain: "/img/avatar-other-main-avatar-4.svg",
    navigationMenuOverlapClassName: {},
  },
};

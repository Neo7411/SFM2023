/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { StandardCollection202 } from "../../icons/StandardCollection202";
import { NavigationMenu } from "../NavigationMenu";
import "./style.css";

export const Naviga = ({
  className,
  navigationMenu = <StandardCollection202 className="standard-collection" />,
  navigationMenuNavigationAvatarOtherMainAvatarOtherMain = "/img/avatar-other-main-avatar-4.svg",
  navigationMenuOverlapClassName,
}) => {
  return (
    <div className={`naviga ${className}`}>
      <NavigationMenu
        className="navigation-menu-horizontal-example-desktop-main-app"
        itemsClassName="navigation-menu-instance"
        navigationAvatarOtherMainAvatarOtherMain={navigationMenuNavigationAvatarOtherMainAvatarOtherMain}
        overlapClassName={navigationMenuOverlapClassName}
        override={navigationMenu}
      />
    </div>
  );
};

Naviga.propTypes = {
  navigationMenuNavigationAvatarOtherMainAvatarOtherMain: PropTypes.string,
};

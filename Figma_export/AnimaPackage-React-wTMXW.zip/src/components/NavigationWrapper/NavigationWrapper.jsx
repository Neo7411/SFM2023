/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";
import { IconOutlinedOtherShopShoppingBag4 } from "../../icons/IconOutlinedOtherShopShoppingBag4";
import { BadgeQuantity } from "../BadgeQuantity";
import "./style.css";

export const NavigationWrapper = ({ className }) => {
  return (
    <div className={`navigation-wrapper ${className}`}>
      <div className="div">
        <IconOutlinedOtherShopShoppingBag4 className="icon-outlined-other" />
        <BadgeQuantity className="badge-quantity-indicator-default" text="4" />
      </div>
    </div>
  );
};

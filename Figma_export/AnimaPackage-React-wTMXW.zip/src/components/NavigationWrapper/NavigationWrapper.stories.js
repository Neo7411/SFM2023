import { NavigationWrapper } from ".";

export default {
  title: "Components/NavigationWrapper",
  component: NavigationWrapper,
};

export const Default = {
  args: {
    className: {},
  },
};

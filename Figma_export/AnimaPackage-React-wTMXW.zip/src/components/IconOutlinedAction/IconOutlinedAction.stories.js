import { IconOutlinedAction } from ".";

export default {
  title: "Components/IconOutlinedAction",
  component: IconOutlinedAction,
};

export const Default = {
  args: {},
};

import { LogoMain } from ".";

export default {
  title: "Components/LogoMain",
  component: LogoMain,
};

export const Default = {
  args: {
    className: {},
  },
};

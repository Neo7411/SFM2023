/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { DivWrapper } from "../DivWrapper";
import { LogoMain } from "../LogoMain";
import { Navigation } from "../Navigation";
import { NavigationWrapper } from "../NavigationWrapper";
import { TextfieldSearch } from "../TextfieldSearch";
import "./style.css";

export const NavigationMenu = ({
  className,
  overlapClassName,
  navigationAvatarOtherMainAvatarOtherMain = "/img/avatar-other-main-avatar-3.svg",
  itemsClassName,
  override = <LogoMain className="logo-main-instance" />,
}) => {
  return (
    <div className={`navigation-menu ${className}`}>
      <div className={`overlap ${overlapClassName}`}>
        <Navigation
          avatarOtherMainAvatarOtherMain={navigationAvatarOtherMainAvatarOtherMain}
          className="navigation-horizontal-elements-profile-default"
        />
        <NavigationWrapper className="navigation-horizontal-elements-cart-added" />
        <TextfieldSearch
          className="textfield-search-default"
          divClassName="textfield-search-default-instance"
          iconOutlinedActionMainSearch2StyleOverrideClassName="textfield-search-instance"
        />
        <div className={`items ${itemsClassName}`}>
          <div className="secondary-items">
            <DivWrapper className="navigation-horizontal-elements-item-default" text="Restaurants" />
            <DivWrapper className="navigation-horizontal-elements-item-default" text="Deals" />
          </div>
          <img className="divider" alt="Divider" src="/img/divider-2.svg" />
          <DivWrapper className="navigation-horizontal-elements-item-default" text="My orders" />
        </div>
        {override}
      </div>
    </div>
  );
};

NavigationMenu.propTypes = {
  navigationAvatarOtherMainAvatarOtherMain: PropTypes.string,
};

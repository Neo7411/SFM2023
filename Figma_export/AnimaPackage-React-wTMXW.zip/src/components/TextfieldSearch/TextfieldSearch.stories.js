import { TextfieldSearch } from ".";

export default {
  title: "Components/TextfieldSearch",
  component: TextfieldSearch,
};

export const Default = {
  args: {
    className: {},
    iconOutlinedActionMainSearch2StyleOverrideClassName: {},
    divClassName: {},
  },
};

/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";
import { IconOutlinedActionMainSearch2 } from "../../icons/IconOutlinedActionMainSearch2";
import "./style.css";

export const TextfieldSearch = ({ className, iconOutlinedActionMainSearch2StyleOverrideClassName, divClassName }) => {
  return (
    <div className={`textfield-search ${className}`}>
      <IconOutlinedActionMainSearch2 className={iconOutlinedActionMainSearch2StyleOverrideClassName} />
      <div className={`text-wrapper ${divClassName}`}>Search</div>
    </div>
  );
};

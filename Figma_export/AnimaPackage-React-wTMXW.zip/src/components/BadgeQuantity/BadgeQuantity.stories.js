import { BadgeQuantity } from ".";

export default {
  title: "Components/BadgeQuantity",
  component: BadgeQuantity,
};

export const Default = {
  args: {
    className: {},
    text: "99",
  },
};

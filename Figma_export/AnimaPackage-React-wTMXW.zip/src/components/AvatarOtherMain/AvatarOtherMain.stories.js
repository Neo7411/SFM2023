import { AvatarOtherMain } from ".";

export default {
  title: "Components/AvatarOtherMain",
  component: AvatarOtherMain,
};

export const Default = {
  args: {
    className: {},
    avatarOtherMain: "/img/avatar-other-main-avatar-1.svg",
  },
};

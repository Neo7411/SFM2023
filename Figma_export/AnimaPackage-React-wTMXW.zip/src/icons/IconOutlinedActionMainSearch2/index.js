export { IconOutlinedActionMainSearch2 } from "./IconOutlinedActionMainSearch2";

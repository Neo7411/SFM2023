export { IconOutlinedOtherOtherCreditCard } from "./IconOutlinedOtherOtherCreditCard";

export { IconOutlinedOtherLocationMapPin } from "./IconOutlinedOtherLocationMapPin";

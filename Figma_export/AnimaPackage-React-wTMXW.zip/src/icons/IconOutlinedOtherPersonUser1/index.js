export { IconOutlinedOtherPersonUser1 } from "./IconOutlinedOtherPersonUser1";

export { IconOutlinedActionShieldShieldOn1 } from "./IconOutlinedActionShieldShieldOn1";

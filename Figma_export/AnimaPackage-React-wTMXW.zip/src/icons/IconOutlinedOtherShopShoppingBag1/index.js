export { IconOutlinedOtherShopShoppingBag1 } from "./IconOutlinedOtherShopShoppingBag1";

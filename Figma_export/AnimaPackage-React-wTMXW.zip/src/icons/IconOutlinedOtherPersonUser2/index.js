export { IconOutlinedOtherPersonUser2 } from "./IconOutlinedOtherPersonUser2";

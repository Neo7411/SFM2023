export { IconOutlinedActionMainSearch1 } from "./IconOutlinedActionMainSearch1";

export { IconOutlinedOtherShopShoppingBag4 } from "./IconOutlinedOtherShopShoppingBag4";

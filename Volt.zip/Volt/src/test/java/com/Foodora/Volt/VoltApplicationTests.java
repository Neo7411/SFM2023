package com.Foodora.Volt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VoltApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.Foodora.Volt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VoltApplication {

	public static void main(String[] args) {
		SpringApplication.run(VoltApplication.class, args);
	}

}
